/**
 * EduLeads Kerala — SVG Logo Components
 *
 * EduLeadsLogoMark  – just the icon badge (rounded square + graduation cap)
 * EduLeadsLogo      – horizontal lockup: icon + "EduLeads" wordmark + "Kerala" tag
 * EduLeadsLogoDark  – same lockup but text in white (for dark backgrounds)
 */

interface LogoMarkProps {
  size?: number;
}

export function EduLeadsLogoMark({ size = 36 }: LogoMarkProps) {
  const id = `elBg_${size}`;
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 40 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-label="EduLeads Kerala"
    >
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="40" y2="40" gradientUnits="userSpaceOnUse">
          <stop stopColor="#1E3A5F" />
          <stop offset="0.6" stopColor="#254d7a" />
          <stop offset="1" stopColor="#2e6096" />
        </linearGradient>
      </defs>

      {/* Badge background */}
      <rect width="40" height="40" rx="10" fill={`url(#${id})`} />

      {/* ── Graduation cap ──────────────────────────────── */}

      {/* Board (diamond / mortarboard brim) */}
      <path
        d="M20 18.5 L30 24 L20 29.5 L10 24 Z"
        fill="white"
        fillOpacity="0.92"
      />

      {/* Cap crown (sits on top of board) */}
      <rect
        x="15.5" y="12" width="9" height="10"
        rx="1.5"
        fill="white"
      />

      {/* Crown highlight stripe — gives depth */}
      <rect
        x="15.5" y="12" width="9" height="3.5"
        rx="1.5"
        fill="white"
        fillOpacity="0.25"
      />

      {/* Top button */}
      <circle cx="20" cy="11.5" r="2" fill="white" />

      {/* Tassel string — horizontal then vertical */}
      <path
        d="M24.5 13 L31 13 L31 21"
        stroke="white"
        strokeWidth="1.6"
        strokeLinecap="round"
        strokeLinejoin="round"
        strokeOpacity="0.75"
        fill="none"
      />

      {/* Tassel end — three small dashes */}
      <line x1="29" y1="21" x2="29" y2="23.5" stroke="white" strokeWidth="1.4" strokeLinecap="round" strokeOpacity="0.7" />
      <line x1="31" y1="21" x2="31" y2="24" stroke="white" strokeWidth="1.4" strokeLinecap="round" strokeOpacity="0.7" />
      <line x1="33" y1="21" x2="33" y2="23" stroke="white" strokeWidth="1.4" strokeLinecap="round" strokeOpacity="0.7" />

      {/* Kerala green dot accent — bottom-right corner */}
      <circle cx="33" cy="33" r="3.5" fill="#2D7D46" />
      <circle cx="33" cy="33" r="1.8" fill="white" fillOpacity="0.9" />
    </svg>
  );
}

interface LogoProps {
  size?: number;
  onDark?: boolean;
}

export function EduLeadsLogo({ size = 36, onDark = false }: LogoProps) {
  const textColor = onDark ? 'white' : '#0f2137';
  const subColor = onDark ? 'rgba(255,255,255,0.55)' : '#64748b';
  const scale = size / 36;
  const textSize = Math.round(15 * scale);
  const subSize = Math.round(11 * scale);

  return (
    <div style={{ display: 'inline-flex', alignItems: 'center', gap: Math.round(10 * scale) }}>
      <EduLeadsLogoMark size={size} />
      <div style={{ lineHeight: 1 }}>
        <div style={{
          fontFamily: 'Inter, -apple-system, sans-serif',
          fontWeight: 800,
          fontSize: textSize,
          color: textColor,
          letterSpacing: '-0.02em',
          lineHeight: 1.15,
        }}>
          EduLeads
        </div>
        <div style={{
          fontFamily: 'Inter, -apple-system, sans-serif',
          fontWeight: 500,
          fontSize: subSize,
          color: subColor,
          letterSpacing: '0.04em',
          lineHeight: 1.2,
          marginTop: 1,
        }}>
          Kerala
        </div>
      </div>
    </div>
  );
}

export default EduLeadsLogo;
