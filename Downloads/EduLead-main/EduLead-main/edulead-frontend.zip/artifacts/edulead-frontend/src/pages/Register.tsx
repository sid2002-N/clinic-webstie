import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from '../lib/axios';
import { useAuthStore, Plan, Role } from '../store/authStore';
import { GraduationCap, Loader2, ArrowLeft } from 'lucide-react';
import { jwtDecode } from 'jwt-decode';

interface JWTPayload {
  user_id: string;
  tenant_id: string;
  tenant_name: string;
  plan: Plan;
  role: Role;
}

export default function Register() {
  const navigate = useNavigate();
  const { setAuth } = useAuthStore();
  const [form, setForm] = useState({
    college_name: '',
    tenant_type: 'college',
    full_name: '',
    email: '',
    password: '',
    confirm_password: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [serverError, setServerError] = useState('');
  const [loading, setLoading] = useState(false);

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.college_name.trim()) e.college_name = 'Name is required';
    if (!form.full_name.trim()) e.full_name = 'Your name is required';
    if (!form.email.includes('@')) e.email = 'Valid email required';
    if (form.password.length < 8) e.password = 'Minimum 8 characters';
    if (form.password !== form.confirm_password) e.confirm_password = 'Passwords do not match';
    return e;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setForm((f) => ({ ...f, [e.target.name]: e.target.value }));
    setErrors((err) => ({ ...err, [e.target.name]: '' }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const v = validate();
    if (Object.keys(v).length > 0) { setErrors(v); return; }
    setLoading(true);
    setServerError('');
    try {
      const res = await api.post('/auth/register/', {
        college_name: form.college_name,
        tenant_type: form.tenant_type,
        full_name: form.full_name,
        email: form.email,
        password: form.password,
      });
      const { access, refresh } = res.data;
      const decoded = jwtDecode<JWTPayload>(access);
      setAuth({
        accessToken: access,
        refreshToken: refresh,
        userId: decoded.user_id,
        tenantId: decoded.tenant_id,
        tenantName: decoded.tenant_name,
        plan: decoded.plan ?? 'basic',
        role: decoded.role,
      });
      navigate('/onboarding');
    } catch (err: any) {
      setServerError(err.response?.data?.detail || JSON.stringify(err.response?.data) || 'Registration failed.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1E3A5F] to-[#2D7D46] flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-md p-8">
        {/* Back to home */}
        <div className="flex items-center justify-between mb-4">
          <Link to="/" className="inline-flex items-center gap-1.5 text-sm text-[#1E3A5F] hover:underline" style={{ textDecoration: 'none', opacity: 0.7 }}
            onMouseEnter={(e) => { e.currentTarget.style.opacity = '1'; }}
            onMouseLeave={(e) => { e.currentTarget.style.opacity = '0.7'; }}
          >
            <ArrowLeft size={14} />
            Back to home
          </Link>
        </div>
        <div className="flex flex-col items-center mb-6">
          <GraduationCap className="w-10 h-10 text-[#1E3A5F] mb-2" />
          <h1 className="text-2xl font-bold text-[#1E3A5F]">Create Account</h1>
          <p className="text-muted-foreground text-sm mt-1">Join EduLeads Kerala today</p>
        </div>

        {serverError && (
          <div className="bg-red-50 border border-red-200 text-red-700 rounded-lg px-4 py-3 text-sm mb-4">
            {serverError}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">College / Agency Name</label>
            <input name="college_name" value={form.college_name} onChange={handleChange}
              className="w-full border border-border rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#1E3A5F]" placeholder="Kerala Engineering College" />
            {errors.college_name && <p className="text-red-500 text-xs mt-1">{errors.college_name}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Type</label>
            <div className="flex gap-4">
              {['college', 'agency'].map((t) => (
                <label key={t} className="flex items-center gap-2 cursor-pointer">
                  <input type="radio" name="tenant_type" value={t}
                    checked={form.tenant_type === t} onChange={handleChange}
                    className="text-[#1E3A5F]" />
                  <span className="text-sm capitalize">{t}</span>
                </label>
              ))}
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Your Full Name</label>
            <input name="full_name" value={form.full_name} onChange={handleChange}
              className="w-full border border-border rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#1E3A5F]" placeholder="Arun Kumar" />
            {errors.full_name && <p className="text-red-500 text-xs mt-1">{errors.full_name}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Email</label>
            <input name="email" type="email" value={form.email} onChange={handleChange}
              className="w-full border border-border rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#1E3A5F]" placeholder="admin@college.edu" />
            {errors.email && <p className="text-red-500 text-xs mt-1">{errors.email}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Password</label>
            <input name="password" type="password" value={form.password} onChange={handleChange}
              className="w-full border border-border rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#1E3A5F]" placeholder="Min 8 characters" />
            {errors.password && <p className="text-red-500 text-xs mt-1">{errors.password}</p>}
          </div>

          <div>
            <label className="block text-sm font-medium mb-1">Confirm Password</label>
            <input name="confirm_password" type="password" value={form.confirm_password} onChange={handleChange}
              className="w-full border border-border rounded-lg px-3 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-[#1E3A5F]" placeholder="Repeat password" />
            {errors.confirm_password && <p className="text-red-500 text-xs mt-1">{errors.confirm_password}</p>}
          </div>

          <button type="submit" disabled={loading}
            className="w-full bg-[#1E3A5F] text-white py-2.5 rounded-lg text-sm font-medium hover:bg-[#162d4a] transition-colors disabled:opacity-60 flex items-center justify-center gap-2">
            {loading && <Loader2 className="w-4 h-4 animate-spin" />}
            {loading ? 'Creating account…' : 'Create Account'}
          </button>
        </form>

        <p className="text-center text-sm text-muted-foreground mt-6">
          Already have an account?{' '}
          <Link to="/login" className="text-[#1E3A5F] font-medium hover:underline">Sign in</Link>
        </p>
      </div>
    </div>
  );
}
