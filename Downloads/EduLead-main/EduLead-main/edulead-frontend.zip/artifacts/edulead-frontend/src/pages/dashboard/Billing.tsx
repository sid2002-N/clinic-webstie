import { useMutation } from '@tanstack/react-query';
import api from '../../lib/axios';
import { useAuthStore } from '../../store/authStore';
import { CheckCircle2, MessageCircle, Zap, X } from 'lucide-react';
import { useState } from 'react';

const plans = [
  {
    key: 'basic', name: 'Basic', price: '₹2,999',
    features: ['10 leads/month', 'AI WhatsApp counsellor', 'Basic analytics', 'Email support'],
  },
  {
    key: 'pro', name: 'Pro', price: '₹6,999', popular: true,
    features: ['30 leads/month', 'Masked calling', 'Advanced analytics', 'Priority support', 'Chat with students'],
  },
  {
    key: 'premium', name: 'Premium', price: '₹14,999',
    features: ['100 leads/month', 'Exclusive leads', 'Phone number reveal', 'CSV export', 'Dedicated manager'],
  },
];

export default function Billing() {
  const { plan: currentPlan } = useAuthStore();
  const [showModal, setShowModal] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState('');

  const linkMutation = useMutation({
    mutationFn: (plan: string) => api.post('/subscriptions/create-payment-link/', { plan }),
    onSuccess: (res) => {
      if (res.data?.payment_link) window.open(res.data.payment_link, '_blank');
    },
  });

  const handleUpgrade = (planKey: string) => {
    setSelectedPlan(planKey);
    setShowModal(true);
  };

  return (
    <div className="p-5 md:p-8" style={{ maxWidth: 1100, margin: '0 auto' }}>
      <div className="mb-6">
        <p style={{ fontSize: 'var(--text-sm)', color: 'var(--text-tertiary)' }}>Manage your subscription</p>
      </div>

      {/* Current plan banner */}
      <div
        className="flex items-center gap-4 rounded-xl p-4 mb-8"
        style={{ background: 'var(--brand-50)', border: '1px solid var(--brand-100)' }}
      >
        <div
          className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0 font-bold uppercase"
          style={{ background: 'var(--brand-800)', color: 'white', fontSize: 'var(--text-sm)' }}
        >
          {(currentPlan || 'B')[0]}
        </div>
        <div>
          <p className="font-semibold capitalize" style={{ color: 'var(--text-primary)', fontSize: 'var(--text-sm)' }}>
            Current Plan: {currentPlan}
          </p>
          <p style={{ fontSize: 'var(--text-xs)', color: 'var(--text-secondary)' }}>
            Your subscription renews monthly
          </p>
        </div>
        {currentPlan !== 'premium' && (
          <div className="ml-auto flex items-center gap-1.5 px-3 py-1.5 rounded-lg"
            style={{ background: 'var(--warm-fill)', border: '1px solid var(--warm-border)', color: 'var(--warm-text)', fontSize: 'var(--text-xs)', fontWeight: 600 }}>
            <Zap size={12} /> Upgrade available
          </div>
        )}
      </div>

      {/* Plans grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 items-center">
        {plans.map((p) => {
          const isCurrent = p.key === currentPlan;
          return (
            <div
              key={p.key}
              className="relative rounded-xl p-7"
              style={{
                background: 'var(--surface-base)',
                border: isCurrent
                  ? '2px solid var(--green-700)'
                  : p.popular
                  ? '2px solid var(--brand-800)'
                  : '1px solid var(--border-default)',
                boxShadow: p.popular ? 'var(--shadow-lg)' : 'var(--shadow-sm)',
                transform: p.popular ? 'scale(1.02)' : 'scale(1)',
              }}
            >
              {isCurrent && (
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full text-xs font-semibold"
                  style={{ background: 'var(--green-700)', color: 'white' }}>
                  Current Plan
                </div>
              )}
              {!isCurrent && p.popular && (
                <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 px-4 py-1 rounded-full text-xs font-semibold"
                  style={{ background: 'var(--brand-800)', color: 'white' }}>
                  Most Popular
                </div>
              )}

              <div className="mb-1 flex items-center gap-2">
                <h3 className="font-bold" style={{ fontSize: 'var(--text-lg)', color: 'var(--text-primary)' }}>{p.name}</h3>
                <span className={`badge badge-${p.key}`}>{p.name}</span>
              </div>
              <p className="font-black my-4" style={{ fontSize: 'var(--text-4xl)', color: 'var(--text-primary)', lineHeight: 1 }}>
                {p.price}
                <span style={{ fontSize: 'var(--text-sm)', fontWeight: 400, color: 'var(--text-secondary)' }}>/mo</span>
              </p>

              <div className="my-5 h-px" style={{ background: 'var(--border-subtle)' }} />

              <ul className="space-y-3 mb-7">
                {p.features.map((f) => (
                  <li key={f} className="flex items-center gap-2.5">
                    <CheckCircle2 size={15} style={{ color: 'var(--green-600)', flexShrink: 0 }} />
                    <span style={{ fontSize: 'var(--text-sm)', color: 'var(--text-secondary)' }}>{f}</span>
                  </li>
                ))}
              </ul>

              {isCurrent ? (
                <button
                  disabled
                  className="w-full py-2.5 rounded-xl text-sm font-medium"
                  style={{ background: 'var(--surface-muted)', color: 'var(--text-tertiary)', border: '1px solid var(--border-default)', cursor: 'default' }}
                >
                  Active Plan
                </button>
              ) : (
                <button
                  onClick={() => handleUpgrade(p.key)}
                  className="btn btn-primary w-full"
                  style={{ justifyContent: 'center' }}
                >
                  Upgrade to {p.name}
                </button>
              )}
            </div>
          );
        })}
      </div>

      {/* Upgrade modal */}
      {showModal && (
        <div
          className="fixed inset-0 flex items-center justify-center z-50 p-4"
          style={{ background: 'var(--surface-overlay)', backdropFilter: 'blur(4px)' }}
          onClick={() => setShowModal(false)}
        >
          <div
            className="w-full max-w-sm rounded-2xl p-6"
            style={{ background: 'var(--surface-base)', boxShadow: 'var(--shadow-xl)' }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-bold" style={{ fontSize: 'var(--text-lg)', color: 'var(--text-primary)' }}>
                Upgrade to {selectedPlan.charAt(0).toUpperCase() + selectedPlan.slice(1)}
              </h3>
              <button onClick={() => setShowModal(false)} style={{ color: 'var(--text-tertiary)' }}>
                <X size={18} />
              </button>
            </div>
            <div
              className="rounded-xl p-4 flex items-start gap-3 mb-5"
              style={{ background: 'var(--green-50)', border: '1px solid var(--green-100)' }}
            >
              <MessageCircle size={20} style={{ color: 'var(--green-700)', flexShrink: 0, marginTop: 1 }} />
              <p style={{ fontSize: 'var(--text-sm)', color: 'var(--text-primary)', lineHeight: 1.5 }}>
                Contact us on WhatsApp at <strong>+91-XXXXXXXXXX</strong>. We'll activate your plan within 2 hours of payment.
              </p>
            </div>
            <div className="flex gap-3">
              <button onClick={() => setShowModal(false)} className="btn btn-secondary flex-1" style={{ justifyContent: 'center' }}>
                Cancel
              </button>
              <a
                href="https://wa.me/91XXXXXXXXXX"
                target="_blank"
                rel="noreferrer"
                className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl text-sm font-medium"
                style={{ background: '#25D366', color: 'white', textDecoration: 'none' }}
              >
                <MessageCircle size={15} /> WhatsApp
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
